## Sistema de localização de pontos de descarte 

Para instalar as dependências rodar o comando no terminal de ambos os projetos
```sh
npm install
``` 

Para rodar o front e o back executar o comando no terminal de ambos os projetos
```sh
npm start
```  

Rodar o front em 
```sh
http://localhost:4200/
```